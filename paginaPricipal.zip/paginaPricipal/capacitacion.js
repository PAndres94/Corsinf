// Mostrar la barra de búsqueda cuando se haga clic en la sección de "Capacitaciones"
document.querySelector('.title').addEventListener('click', function() {
    var searchBar = document.getElementById('searchBar');
    searchBar.style.display = (searchBar.style.display === 'none' || searchBar.style.display === '') ? 'block' : 'none';
});
