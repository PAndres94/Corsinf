document.addEventListener("DOMContentLoaded", () => {
    console.log("Página cargada correctamente.");

    // Datos de los socios
    const socios = [
        {
            nombre: "Escuela de Educación Básica Ángel de la Guarda",
            categoria: "sierra",
            imagen: "images/Angel-de-la-Guarda.png",
            enlace: "https://www.facebook.com/angeldelaguardaciag/?locale=es_LA"
        },
        {
            nombre: "Colegio Johannes Kepler",
            categoria: "amazonia",
            imagen: "images/Johannes-Kepler.png",
            enlace: "https://www.jkepler.edu.ec/"
        },
        {
            nombre: "Colegio Particular Batalla de Jambelí",
            categoria: "sierra",
            imagen: "images/Batalla-de-Jambeli.png",
            enlace: "https://www.facebook.com/ColegioBatalladeJambeli/?locale=es_LA"
        }
        // Puedes agregar más socios aquí
    ];

    // Seleccionar los filtros
    const sociosContainer = document.getElementById("socios-container");
    const categoryFilter = document.getElementById("category-filter");
    const searchFilter = document.getElementById("search-filter");
    const sortFilter = document.getElementById("sort-filter");

    // Función para renderizar los socios
    const renderSocios = () => {
        const categoryValue = categoryFilter.value;
        const searchValue = searchFilter.value.toLowerCase();
        const sortValue = sortFilter.value;

        // Filtrar socios según la categoría seleccionada y el texto de búsqueda
        let filteredSocios = socios.filter(socio => {
            const matchesCategory = categoryValue === "todas" || socio.categoria === categoryValue;
            const matchesSearch = socio.nombre.toLowerCase().includes(searchValue);
            return matchesCategory && matchesSearch;
        });

        // Ordenar los socios si se selecciona un filtro de orden
        if (sortValue === "ascendente") {
            filteredSocios.sort((a, b) => a.nombre.localeCompare(b.nombre));
        } else if (sortValue === "descendente") {
            filteredSocios.sort((a, b) => b.nombre.localeCompare(a.nombre));
        }

        // Limpiar el contenedor de socios antes de renderizar
        sociosContainer.innerHTML = "";

        // Agregar los socios filtrados al contenedor
        filteredSocios.forEach(socio => {
            const socioElement = document.createElement("div");
            socioElement.classList.add("socio");

            const socioContent = `
                <img src="${socio.imagen}" alt="${socio.nombre}">
                <h3>${socio.nombre}</h3>
                <p>Categoría: ${socio.categoria}</p>
                <a href="${socio.enlace}" target="_blank">Ver más</a>
            `;
            socioElement.innerHTML = socioContent;
            sociosContainer.appendChild(socioElement);
        });
    };

    // Ejecutar la renderización inicial
    renderSocios();

    // Agregar eventos a los filtros
    categoryFilter.addEventListener("change", renderSocios);
    searchFilter.addEventListener("input", renderSocios);
    sortFilter.addEventListener("change", renderSocios);
});
